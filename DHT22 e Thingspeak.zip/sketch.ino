

///////	EXTRUTURA MODELO ARDUINO / ESP32  ///////
//
// EMPRESA: IoT TECNOLOGIA
// PROJETO: Automação de Sensores e Atuadores
// GERENTE: PROF. GIRAFALES
// TECNICO: CHAVES
// Data   : 00/08/2026
//
////////////////////////////////////////////////

#include <WiFi.h>

#include "DHTesp.h"

#include "ThingSpeak.h"

const int DHT_PIN         = 15;            // Pino GPIO do sensor DHT22

const char* WIFI_NAME     = "Wokwi-GUEST"; // Nome (SSID) da rede Wi-Fi
const char* WIFI_PASSWORD = "";            // Senha da rede Wi-Fi

//============  ThingSpeak Conexao  =================
const int myChannelNumber = 3777704;              // Número do canal ThingSpeak
const char* myApiKey      = "YK1Y41JY";           // Chave da API ThingSpeak
const char* server        = "api.thingspeak.com"; // Endereço do servidor ThingSpeak


DHTesp dhtSensor; // Cria uma instância da biblioteca DHTesp

WiFiClient client; // Cria um objeto cliente Wi-Fi

void setup() 
{
 
  Serial.begin(115200);                    // Inicializa a comunicação serial com uma taxa de 115200 baud

  dhtSensor.setup(DHT_PIN, DHTesp::DHT22); // Inicializa o sensor DHT22

  WiFi.begin(WIFI_NAME, WIFI_PASSWORD);    // Conecta à rede Wi-Fi

  while (WiFi.status() != WL_CONNECTED)
        {
          delay(1000);
          Serial.println("Wi-Fi não conectado"); // Exibe uma mensagem caso a Wi-Fi não esteja conectada
        }
  Serial.println("Wi-Fi conectado!");                    // Exibe uma mensagem caso a Wi-Fi esteja conectada
  Serial.println("IP Local: " + String(WiFi.localIP())); // Exibe o endereço IP local

  WiFi.mode(WIFI_STA);        // Define o modo Wi-Fi como estação

  ThingSpeak.begin(client);   // Inicializa a biblioteca ThingSpeak
}

void loop()
 {
  
  TempAndHumidity  data = dhtSensor.getTempAndHumidity(); // Lê temperatura e umidade do sensor DHT22
  
  ThingSpeak.setField(1, data.temperature); // Define o valor do campo 1 no canal ThingSpeak como a temperatura
 
  ThingSpeak.setField(2, data.humidity);    // Define o valor do campo 2 no canal ThingSpeak como a umidade

  
  int status = ThingSpeak.writeFields(myChannelNumber, myApiKey); // Escreve os dados no canal ThingSpeak
  
  Serial.println("Temp: " + String(data.temperature, 2) + "°C");  // Exibe o valor da temperatura com 2 casas decimais

  Serial.println("Umidade: " + String(data.humidity, 1) + "%");   // Exibe o valor da umidade com 1 casa decimal
  
  if(status == 200)
    {
      Serial.println("Dados enviados com sucesso"); // Exibe uma mensagem caso os dados sejam enviados ao ThingSpeak com sucesso
    }
  
  else{
        Serial.println("Erro ao enviar dados: " + String(status)); // Exibe uma mensagem de erro com o código HTTP caso ocorra um erro ao enviar os dados
      }

  Serial.println("---"); // Exibe uma linha separadora

  delay(20000); // Aguarda 20 segundos
}
